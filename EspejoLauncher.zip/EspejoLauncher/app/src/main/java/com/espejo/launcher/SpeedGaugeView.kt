package com.espejo.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class SpeedGaugeView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var speed: Int = 0
        set(v) { field = v; invalidate() }
    var status: String = "Sin GPS"
        set(v) { field = v; invalidate() }

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x33FFFFFF; strokeCap = Paint.Cap.ROUND
    }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFFE8731A.toInt(); strokeCap = Paint.Cap.ROUND
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBFB3AB.toInt(); textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val size = min(w, h)
        val stroke = size * 0.07f
        track.strokeWidth = stroke
        prog.strokeWidth = stroke
        val rect = RectF(
            w / 2 - size / 2 + stroke, h / 2 - size / 2 + stroke,
            w / 2 + size / 2 - stroke, h / 2 + size / 2 - stroke
        )
        c.drawArc(rect, 135f, 270f, false, track)
        val sweep = 270f * min(speed, 180) / 180f
        if (sweep > 0f) c.drawArc(rect, 135f, sweep, false, prog)
        big.textSize = size * 0.32f
        c.drawText(speed.toString(), w / 2, h / 2 + size * 0.08f, big)
        small.textSize = size * 0.10f
        c.drawText("km/h", w / 2, h / 2 + size * 0.22f, small)
        small.textSize = size * 0.08f
        c.drawText(status, w / 2, h / 2 + size * 0.33f, small)
    }
}
