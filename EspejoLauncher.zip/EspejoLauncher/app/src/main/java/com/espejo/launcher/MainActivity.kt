package com.espejo.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.bluetooth.BluetoothAdapter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

@Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: AppAdapter
    private lateinit var gauge: SpeedGaugeView
    private lateinit var carView: ImageView
    private lateinit var tripView: TextView
    private lateinit var titleView: TextView
    private lateinit var drawer: View
    private lateinit var dock: LinearLayout
    private lateinit var songView: TextView
    private lateinit var artistView: TextView
    private lateinit var artView: ImageView
    private lateinit var playBtn: ImageView
    private lateinit var obdInfo: TextView
    private var obdLiveAt = 0L
    private val obd = ObdManager(
        onData = { d -> runOnUiThread { showObd(d) } },
        onStatus = { s -> runOnUiThread { obdInfo.text = s } }
    )

    private var apps: List<AppInfo> = emptyList()
    private var controller: MediaController? = null
    private var lastLoc: Location? = null
    private var tripM = 0f

    private val musicDefaults = listOf("com.spotify.music", "com.google.android.apps.youtube.music")
    private val navDefaults = listOf("com.google.android.apps.maps", "com.waze")
    private val autoPkg = "com.google.android.projection.gearhead"

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) saveCar(uri)
    }

    private val mediaCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { updateMedia() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { updateMedia() }
    }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pickController(list)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)

        gauge = findViewById(R.id.gauge)
        carView = findViewById(R.id.car)
        tripView = findViewById(R.id.trip)
        titleView = findViewById(R.id.title)
        drawer = findViewById(R.id.drawer)
        dock = findViewById(R.id.dock)
        songView = findViewById(R.id.song)
        artistView = findViewById(R.id.artist)
        artView = findViewById(R.id.art)
        playBtn = findViewById(R.id.play)
        obdInfo = findViewById(R.id.obdInfo)
        obdInfo.setOnClickListener { connectObd() }
        obdInfo.setOnLongClickListener { pickObd(); true }

        titleView.text = prefs.getString("title", "TOYOTA COROLLA")
        titleView.setOnLongClickListener { askTitle(); true }

        tripM = prefs.getFloat("trip_m", 0f)
        showTrip()
        tripView.setOnLongClickListener {
            tripM = 0f
            prefs.edit().putFloat("trip_m", 0f).apply()
            showTrip()
            Toast.makeText(this, "Recorrido en cero", Toast.LENGTH_SHORT).show()
            true
        }

        loadCar()
        carView.setOnClickListener { pickImage.launch(arrayOf("image/*")) }
        carView.setOnLongClickListener {
            File(filesDir, "car.jpg").delete()
            carView.setImageResource(R.drawable.ic_car)
            true
        }

        findViewById<View>(R.id.musicCard).setOnClickListener {
            if (!hasNotifAccess()) openNotifAccess() else launch(musicPkg())
        }
        findViewById<View>(R.id.prev).setOnClickListener { controller?.transportControls?.skipToPrevious() }
        findViewById<View>(R.id.next).setOnClickListener { controller?.transportControls?.skipToNext() }
        playBtn.setOnClickListener { togglePlay() }
        findViewById<View>(R.id.aaCard).setOnClickListener { launch(autoPkg) }
        findViewById<View>(R.id.navCard).setOnClickListener { launch(navPkg()) }

        adapter = AppAdapter(
            onClick = { drawer.visibility = View.GONE; launch(it.pkg) },
            onLongClick = { askRole(it) }
        )
        val dm = resources.displayMetrics
        val rows = ((dm.heightPixels / dm.density) / 120).toInt().coerceIn(2, 4)
        findViewById<RecyclerView>(R.id.apps).apply {
            layoutManager = GridLayoutManager(this@MainActivity, rows, RecyclerView.HORIZONTAL, false)
            adapter = this@MainActivity.adapter
        }
        findViewById<View>(R.id.closeDrawer).setOnClickListener { drawer.visibility = View.GONE }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
        if (Build.VERSION.SDK_INT >= 31 && !hasBtPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        renderDock()
        startSpeed()
        attachMedia()
        if (prefs.getString("obd", null) != null) connectObd()
    }

    override fun onPause() {
        super.onPause()
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(this)
        } catch (_: Exception) {}
        detachMedia()
        obd.stop()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        drawer.visibility = View.GONE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) drawer.visibility = View.GONE
    }

    // ---------- Apps y dock ----------

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        adapter.submit(apps)
    }

    private fun installed(pkg: String) = apps.any { it.pkg == pkg }

    private fun musicPkg(): String? =
        prefs.getString("music", null)?.takeIf { installed(it) } ?: musicDefaults.firstOrNull { installed(it) }

    private fun navPkg(): String? =
        prefs.getString("nav", null)?.takeIf { installed(it) } ?: navDefaults.firstOrNull { installed(it) }

    private fun iconOf(pkg: String?) = apps.firstOrNull { it.pkg == pkg }?.icon

    private fun renderDock() {
        dock.removeAllViews()
        val pm = packageManager
        val dialIntent = Intent(Intent.ACTION_DIAL)
        val dialIcon = pm.resolveActivity(dialIntent, 0)?.loadIcon(pm)
        val settingsIntent = Intent(Settings.ACTION_SETTINGS)
        val settingsIcon = pm.resolveActivity(settingsIntent, 0)?.loadIcon(pm)

        addDock("Música", iconOf(musicPkg())) { launch(musicPkg()) }
        addDock("Teléfono", dialIcon) { startActivity(dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        addDock("Android Auto", iconOf(autoPkg)) { launch(autoPkg) }
        addDock("Navegación", iconOf(navPkg())) { launch(navPkg()) }
        addDock("Apps", ContextCompat.getDrawable(this, R.drawable.ic_apps)) { drawer.visibility = View.VISIBLE }
        addDock("Ajustes", settingsIcon) { startActivity(settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun addDock(label: String, icon: android.graphics.drawable.Drawable?, action: () -> Unit) {
        val v = LayoutInflater.from(this).inflate(R.layout.item_dock, dock, false)
        v.findViewById<ImageView>(R.id.dIcon).setImageDrawable(icon)
        v.findViewById<TextView>(R.id.dLabel).text = label
        v.setOnClickListener { try { action() } catch (_: Exception) {} }
        dock.addView(v)
    }

    private fun askRole(app: AppInfo) {
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(arrayOf("Usar como música", "Usar como navegación")) { _, which ->
                prefs.edit().putString(if (which == 0) "music" else "nav", app.pkg).apply()
                renderDock()
            }
            .show()
    }

    private fun askTitle() {
        val et = EditText(this)
        et.setText(titleView.text)
        AlertDialog.Builder(this)
            .setTitle("Nombre del auto")
            .setView(et)
            .setPositiveButton("Guardar") { _, _ ->
                val t = et.text.toString().trim().uppercase()
                if (t.isNotEmpty()) {
                    prefs.edit().putString("title", t).apply()
                    titleView.text = t
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun launch(pkg: String?) {
        if (pkg == null) return
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    // ---------- Foto del auto ----------

    private fun loadCar() {
        val f = File(filesDir, "car.jpg")
        if (f.exists()) carView.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
    }

    private fun saveCar(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) return
            File(filesDir, "car.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            carView.setImageBitmap(bmp)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Música ----------

    private fun hasNotifAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openNotifAccess() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun attachMedia() {
        if (!hasNotifAccess()) {
            songView.text = "Activar música"
            artistView.text = "Toca para dar acceso"
            return
        }
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, MediaListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pickController(msm.getActiveSessions(cn))
        } catch (_: Exception) {}
    }

    private fun detachMedia() {
        try {
            (getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager)
                .removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {}
        controller?.unregisterCallback(mediaCallback)
        controller = null
    }

    private fun pickController(list: List<MediaController>?) {
        controller?.unregisterCallback(mediaCallback)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(mediaCallback)
        updateMedia()
    }

    private fun updateMedia() {
        val c = controller
        if (c == null) {
            songView.text = "Sin música"
            artistView.text = "Toca para abrir tu app"
            artView.setImageResource(R.drawable.ic_music)
            playBtn.setImageResource(android.R.drawable.ic_media_play)
            return
        }
        val m = c.metadata
        songView.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
        artistView.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (art != null) artView.setImageBitmap(art) else artView.setImageResource(R.drawable.ic_music)
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        playBtn.setImageResource(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
    }

    private fun togglePlay() {
        val c = controller
        if (c == null) { launch(musicPkg()); return }
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }

    // ---------- OBD ----------

    private fun hasBtPermission() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun connectObd() {
        val addr = prefs.getString("obd", null)
        if (addr == null) { pickObd(); return }
        if (!hasBtPermission()) { obdInfo.text = "Falta permiso Bluetooth"; return }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) { obdInfo.text = "Activa el Bluetooth"; return }
        if (obd.isRunning()) return
        try {
            obd.start(adapter.getRemoteDevice(addr))
        } catch (e: Exception) {
            obdInfo.text = "OBD error"
        }
    }

    @SuppressLint("MissingPermission")
    private fun pickObd() {
        if (!hasBtPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) { obdInfo.text = "Activa el Bluetooth"; return }
        val devices = adapter.bondedDevices.toList()
        if (devices.isEmpty()) {
            Toast.makeText(this, "Primero empareja tu OBD en Ajustes > Bluetooth (clave 1234 o 0000)", Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elige tu OBD")
            .setItems(names) { _, which ->
                prefs.edit().putString("obd", devices[which].address).apply()
                obd.stop()
                connectObd()
            }
            .show()
    }

    private fun showObd(d: ObdManager.Data) {
        if (d.speed != null) {
            obdLiveAt = System.currentTimeMillis()
            gauge.speed = d.speed
            gauge.status = "OBD"
        }
        val parts = mutableListOf<String>()
        d.rpm?.let { parts.add("$it rpm") }
        d.coolant?.let { parts.add("$it°C") }
        d.volts?.let { parts.add(it) }
        d.fuel?.let { lastFuel = it }
        lastFuel?.let { parts.add("⛽$it%") }
        if (parts.isNotEmpty()) obdInfo.text = parts.joinToString(" · ")
    }

    private var lastFuel: Int? = null

    // ---------- GPS ----------

    private fun showTrip() {
        tripView.text = String.format("%.1f km", tripM / 1000f)
    }

    @SuppressLint("MissingPermission")
    private fun startSpeed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        } catch (_: Exception) {}
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        startSpeed()
        if (hasBtPermission() && prefs.getString("obd", null) != null) connectObd()
    }

    override fun onLocationChanged(location: Location) {
        val kmh = if (location.hasSpeed()) (location.speed * 3.6f).toInt() else 0
        if (System.currentTimeMillis() - obdLiveAt > 4000) {
            gauge.speed = kmh
            gauge.status = "GPS"
        }
        val prev = lastLoc
        if (prev != null && location.accuracy < 40f && kmh > 3) {
            val d = prev.distanceTo(location)
            if (d < 500f) {
                tripM += d
                prefs.edit().putFloat("trip_m", tripM).apply()
                showTrip()
            }
        }
        lastLoc = location
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {
        gauge.speed = 0
        gauge.status = "Sin GPS"
    }
}
